# iXGAME — New Site From Scratch

واجهة جديدة مستقلة بملف HTML واحد، مع CSS وJavaScript مدمجين.
- Responsive للجوال والكمبيوتر وPS4 Browser.
- Red intro screen.
- Firmware selector.
- Animated gold waiting screen.
- لا توجد أسطر payload/حقن ظاهرة للمستخدم.

> هذه الحزمة تبني الواجهة فقط. لا تحتوي على كود استغلال أو payload لتجاوز حماية PS4.
